import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HubungiKamiPage } from './hubungi-kami';

@NgModule({
  declarations: [
    HubungiKamiPage,
  ],
  imports: [
    IonicPageModule.forChild(HubungiKamiPage),
  ],
})
export class HubungiKamiPageModule {}
