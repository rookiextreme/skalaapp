import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SenaraiGambarPage } from './senarai-gambar';

@NgModule({
  declarations: [
    SenaraiGambarPage,
  ],
  imports: [
    IonicPageModule.forChild(SenaraiGambarPage),
  ],
})
export class SenaraiGambarPageModule {}
