import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { IonicStorageModule } from '@ionic/storage';
//import { HttpModule } from "@angular/http"; // api
import { HttpClientModule } from '@angular/common/http';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { Camera } from '@ionic-native/camera';
import { File } from '@ionic-native/file';
import { FileTransfer } from '@ionic-native/file-transfer';


import { LoginPage } from './../pages/login/login';
import { ButiranProjekPage } from '../pages/butiran-projek/butiran-projek';
import { CarianPage } from '../pages/carian/carian';
import { HubungiKamiPage } from '../pages/hubungi-kami/hubungi-kami';
import { InfoRingkasPage } from '../pages/info-ringkas/info-ringkas';
import { SenaraiKontrakOfflinePage } from '../pages/senarai-kontrak-offline/senarai-kontrak-offline';
import { SenaraiProjekOfflinePage } from '../pages/senarai-projek-offline/senarai-projek-offline';
import { SenaraiProjekPage } from '../pages/senarai-projek/senarai-projek';
import { ButiranKontrakPage } from '../pages/butiran-kontrak/butiran-kontrak';
import { CatatanKontrakPage } from '../pages/catatan-kontrak/catatan-kontrak';
import { TambahCatatanKontrakPage } from '../pages/tambah-catatan-kontrak/tambah-catatan-kontrak';
import { SenaraiGambarPage } from '../pages/senarai-gambar/senarai-gambar';
import { MuatNaikGambarPage } from '../pages/muat-naik-gambar/muat-naik-gambar';
import { PaparGambarPage } from '../pages/papar-gambar/papar-gambar';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    ButiranProjekPage,
    CarianPage,
    HubungiKamiPage,
    InfoRingkasPage,
    SenaraiKontrakOfflinePage,
    SenaraiProjekOfflinePage,
    SenaraiProjekPage,
    ButiranKontrakPage,
    CatatanKontrakPage,
    TambahCatatanKontrakPage,
    SenaraiGambarPage,
    MuatNaikGambarPage,
    PaparGambarPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    //HttpModule,
    HttpClientModule,
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    ButiranProjekPage,
    CarianPage,
    HubungiKamiPage,
    InfoRingkasPage,
    SenaraiKontrakOfflinePage,
    SenaraiProjekOfflinePage,
    SenaraiProjekPage,
    ButiranKontrakPage,
    CatatanKontrakPage,
    TambahCatatanKontrakPage,
    SenaraiGambarPage,
    MuatNaikGambarPage,
    PaparGambarPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Camera,
    File,
    FileTransfer,
    { provide: ErrorHandler, useClass: IonicErrorHandler }
  ]
})
export class AppModule { }
