import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ButiranKontrakPage } from './butiran-kontrak';

@NgModule({
  declarations: [
    ButiranKontrakPage,
  ],
  imports: [
    IonicPageModule.forChild(ButiranKontrakPage),
  ],
})
export class ButiranKontrakPageModule {}
