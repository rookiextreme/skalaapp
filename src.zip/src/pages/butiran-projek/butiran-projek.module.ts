import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ButiranProjekPage } from './butiran-projek';

@NgModule({
  declarations: [
    ButiranProjekPage,
  ],
  imports: [
    IonicPageModule.forChild(ButiranProjekPage),
  ],
})
export class ButiranProjekPageModule {}
