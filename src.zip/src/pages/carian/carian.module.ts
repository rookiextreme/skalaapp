import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CarianPage } from './carian';

@NgModule({
  declarations: [
    CarianPage,
  ],
  imports: [
    IonicPageModule.forChild(CarianPage),
  ],
})
export class CarianPageModule {}
