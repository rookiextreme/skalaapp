import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CatatanKontrakPage } from './catatan-kontrak';

@NgModule({
  declarations: [
    CatatanKontrakPage,
  ],
  imports: [
    IonicPageModule.forChild(CatatanKontrakPage),
  ],
})
export class CatatanKontrakPageModule {}
