import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InfoRingkasPage } from './info-ringkas';

@NgModule({
  declarations: [
    InfoRingkasPage,
  ],
  imports: [
    IonicPageModule.forChild(InfoRingkasPage),
  ],
})
export class InfoRingkasPageModule {}
