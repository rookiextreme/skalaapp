import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MuatNaikGambarPage } from './muat-naik-gambar';

@NgModule({
  declarations: [
    MuatNaikGambarPage,
  ],
  imports: [
    IonicPageModule.forChild(MuatNaikGambarPage),
  ],
})
export class MuatNaikGambarPageModule {}
