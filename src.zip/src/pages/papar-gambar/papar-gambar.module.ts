import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PaparGambarPage } from './papar-gambar';

@NgModule({
  declarations: [
    PaparGambarPage,
  ],
  imports: [
    IonicPageModule.forChild(PaparGambarPage),
  ],
})
export class PaparGambarPageModule {}
