import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SenaraiKontrakOfflinePage } from './senarai-kontrak-offline';

@NgModule({
  declarations: [
    SenaraiKontrakOfflinePage,
  ],
  imports: [
    IonicPageModule.forChild(SenaraiKontrakOfflinePage),
  ],
})
export class SenaraiKontrakOfflinePageModule {}
