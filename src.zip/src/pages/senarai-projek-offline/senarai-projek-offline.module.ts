import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SenaraiProjekOfflinePage } from './senarai-projek-offline';

@NgModule({
  declarations: [
    SenaraiProjekOfflinePage,
  ],
  imports: [
    IonicPageModule.forChild(SenaraiProjekOfflinePage),
  ],
})
export class SenaraiProjekOfflinePageModule {}
