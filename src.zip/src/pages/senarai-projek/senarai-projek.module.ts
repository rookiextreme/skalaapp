import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SenaraiProjekPage } from './senarai-projek';

@NgModule({
  declarations: [
    SenaraiProjekPage,
  ],
  imports: [
    IonicPageModule.forChild(SenaraiProjekPage),
  ],
})
export class SenaraiProjekPageModule {}
