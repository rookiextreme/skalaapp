import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TambahCatatanKontrakPage } from './tambah-catatan-kontrak';

@NgModule({
  declarations: [
    TambahCatatanKontrakPage,
  ],
  imports: [
    IonicPageModule.forChild(TambahCatatanKontrakPage),
  ],
})
export class TambahCatatanKontrakPageModule {}
