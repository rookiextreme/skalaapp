import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { HttpClient } from "@angular/common/http";
import { HttpHeaders } from "@angular/common/http";
import { InfoRingkasPage } from '../info-ringkas/info-ringkas';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  // declare class properties (variables)
  errorMessageIc: string = '';
  errorMessagePwd: string = '';
  noKadPengenalan: string = '670518035324';
  kataLaluan: string = '123456789012';

  constructor(public navCtrl: NavController, public navParams: NavParams, public http: HttpClient, public loadingCtrl: LoadingController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  doLogin() {
    let validation = this.checkLogin();
  }

  // check login
  checkLogin() {
    console.log(this.noKadPengenalan + " " + this.kataLaluan);
    if (this.noKadPengenalan == "") {
      this.errorMessageIc = "Sila masukkan No. Kad Pengenalan";
    } else if (this.noKadPengenalan.length != 12) {
      console.log(this.noKadPengenalan.length);
      this.errorMessageIc = "Panjang No. Kad Pengenalan tidak sah";
    } else {
      this.errorMessageIc = "";
    }

    if (this.kataLaluan == "") {
      var noPwd = 'Sila masukkan Kata Laluan';
      this.errorMessagePwd = noPwd;
    } else if (this.kataLaluan.length < 12) {
      console.log(this.kataLaluan.length);
      this.errorMessagePwd = "Panjang kata laluan tidak sah";
    }

    // if no error at this level, hantar login data ke API
    if ((this.errorMessageIc == "") && (this.errorMessagePwd == "")) {

      this.tryLogin();
    }

  }

  tryLogin() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      })
    };

    let postData = {
      "ic_number": this.noKadPengenalan,
      "password": this.kataLaluan
    };

    let url = "http://admin3-skala.jkr.gov.my/~teras/skala/web/www/api_login_dev.php";

    const loader = this.loadingCtrl.create({
      content: "Please wait...",
      duration: 3000
    });
    loader.present();

    this.http.post(url, postData, httpOptions)
      .subscribe(data => {

        let status = data.status;
        let role = data.role;
        if (status == 'pass') {
          //alert(data.role);
          this.navCtrl.setRoot(InfoRingkasPage);
        } else {
          this.errorMessagePwd = "Kombinasi nama pengguna dan kata laluan tidak sah";
        }

        console.log(data);
        loader.dismiss();
      }, error => {
        console.log(error);
      })
  }

}
